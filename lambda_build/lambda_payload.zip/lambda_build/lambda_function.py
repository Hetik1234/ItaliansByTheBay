import json
import boto3
import os
from datetime import datetime
from botocore.exceptions import ClientError

# --- Clients ---
cloudwatch = boto3.client("cloudwatch")
ses = boto3.client("ses")

ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "hetikchandaria67@gmail.com")  # fallback


def lambda_handler(event, context):
    print("SNS EVENT RECEIVED:")
    print(json.dumps(event))

    # SNS always wraps message inside Records[0]["Sns"]
    try:
        sns_record = event["Records"][0]["Sns"]
        message = sns_record["Message"]
        subject = sns_record.get("Subject", "New Order Notification")

    except Exception as e:
        print("ERROR parsing SNS:", e)
        return {"statusCode": 400, "body": "Invalid SNS event"}

    # ---- 1) Parse Message (Expected: 'Order #9 placed by admin with total €5.49.') ----
    order_id, amount = parse_order_message(message)

    # ---- 2) Push CloudWatch Metrics ----
    push_metrics(order_id, amount)

    # ---- 3) Send SES Email ----
    send_ses_email(
        to_email=ADMIN_EMAIL,
        subject=f"[ItaliansByTheBay] Order #{order_id} placed",
        message=f"Order #{order_id} was placed. Total amount: €{amount}"
    )

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Lambda executed successfully"})
    }


# ----------------------------------------------
#   HELPERS
# ----------------------------------------------

def parse_order_message(message):
    """
    Extract order_id and total amount from SNS message sent by Django.
    """
    try:
        # Extract order ID
        order_id = message.split("#")[1].split(" ")[0]

        # Extract last € amount
        amount_text = message.split("€")[-1].replace(".", "").replace(",", ".")
        amount = float(amount_text)

        print(f"Parsed order_id={order_id}, amount={amount}")
        return order_id, amount

    except Exception as e:
        print("Failed to parse SNS message:", e)
        return "unknown", 0.0


def push_metrics(order_id, amount):
    """
    Push meaningful business KPIs to CloudWatch.
    """
    try:
        cloudwatch.put_metric_data(
            Namespace="ItaliansByTheBay/Orders",
            MetricData=[
                {
                    "MetricName": "OrdersCount",
                    "Timestamp": datetime.utcnow(),
                    "Value": 1,
                    "Unit": "Count"
                },
                {
                    "MetricName": "Revenue",
                    "Timestamp": datetime.utcnow(),
                    "Value": amount,
                    "Unit": "None"
                },
                {
                    "MetricName": "OrderValue",
                    "Timestamp": datetime.utcnow(),
                    "Value": amount,
                    "Unit": "None"
                }
            ]
        )

        print("CloudWatch metrics pushed ✔")

    except Exception as e:
        print("CloudWatch error:", e)


def send_ses_email(to_email, subject, message):
    """
    Sends an SES email (customizable for admin or user).
    """
    try:
        response = ses.send_email(
            Source=to_email,  # from = to (no domain verified issue)
            Destination={"ToAddresses": [to_email]},
            Message={
                "Subject": {"Data": subject},
                "Body": {
                    "Text": {"Data": message},
                },
            }
        )

        print("SES email sent:", response)

    except ClientError as e:
        print("SES ERROR:", e)
    except Exception as e:
        print("Unexpected SES ERROR:", e)
